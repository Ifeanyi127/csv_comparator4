from flask import Flask, request, render_template, send_file, redirect, url_for
import pandas as pd
import os

app = Flask(__name__)

@app.route('/')
def upload_page():
    return render_template('upload.html')

@app.route('/compare_csv', methods=['POST'])
def compare_csv_files():
    file1 = request.files['csvFile1']
    file2 = request.files['csvFile2']
    
    df1 = pd.read_csv(file1)
    df2 = pd.read_csv(file2)

    # Print column names to verify
    print("Columns in df1:", df1.columns)
    print("Columns in df2:", df2.columns)
    
    # Specify the fields to compare
    fields_to_compare = ['Name', 'newcode', 'bankac']

    # Check if the columns exist in both DataFrames
    for field in fields_to_compare:
        if field not in df1.columns or field not in df2.columns:
            return f"Error: '{field}' column not found in one of the CSV files."

    # Convert fields to strings, lowercase, and strip whitespace for comparison
    df1_filtered = df1[fields_to_compare].apply(lambda x: x.astype(str).str.lower().str.strip())
    df2_filtered = df2[fields_to_compare].apply(lambda x: x.astype(str).str.lower().str.strip())

    # Debugging: Print filtered DataFrames to verify content
    print("Filtered df1:\n", df1_filtered.head())
    print("Filtered df2:\n", df2_filtered.head())

    # Function to find matching and non-matching values
    def find_matches(df1_column, df2_column):
        matches = df1_column[df1_column.isin(df2_column)]
        non_matches_df1 = df1_column[~df1_column.isin(df2_column)]
        non_matches_df2 = df2_column[~df2_column.isin(df1_column)]
        return matches, non_matches_df1, non_matches_df2

    # Find matches and non-matches for each field
    name_matches, name_non_matches_df1, name_non_matches_df2 = find_matches(df1_filtered['Name'], df2_filtered['Name'])
    newcode_matches, newcode_non_matches_df1, newcode_non_matches_df2 = find_matches(df1_filtered['newcode'], df2_filtered['newcode'])
    bankac_matches, bankac_non_matches_df1, bankac_non_matches_df2 = find_matches(df1_filtered['bankac'], df2_filtered['bankac'])

    # Debugging: Print matches and non-matches to verify
    print("Name matches:\n", name_matches)
    print("Newcode matches:\n", newcode_matches)
    print("Bankac matches:\n", bankac_matches)
    print("Name non-matches df1:\n", name_non_matches_df1)
    print("Name non-matches df2:\n", name_non_matches_df2)
    print("Newcode non-matches df1:\n", newcode_non_matches_df1)
    print("Newcode non-matches df2:\n", newcode_non_matches_df2)
    print("Bankac non-matches df1:\n", bankac_non_matches_df1)
    print("Bankac non-matches df2:\n", bankac_non_matches_df2)

    # Create DataFrames for the results
    matching_names_df = pd.DataFrame(name_matches, columns=['Name'])
    non_matching_names_df1 = pd.DataFrame(name_non_matches_df1, columns=['Name'])
    non_matching_names_df2 = pd.DataFrame(name_non_matches_df2, columns=['Name'])
    
    matching_newcode_df = pd.DataFrame(newcode_matches, columns=['newcode'])
    non_matching_newcode_df1 = pd.DataFrame(newcode_non_matches_df1, columns=['newcode'])
    non_matching_newcode_df2 = pd.DataFrame(newcode_non_matches_df2, columns=['newcode'])
    
    matching_bankac_df = pd.DataFrame(bankac_matches, columns=['bankac'])
    non_matching_bankac_df1 = pd.DataFrame(bankac_non_matches_df1, columns=['bankac'])
    non_matching_bankac_df2 = pd.DataFrame(bankac_non_matches_df2, columns=['bankac'])

    # Convert DataFrames to HTML for display
    matching_names_html = matching_names_df.to_html(index=False)
    non_matching_names_df1_html = non_matching_names_df1.to_html(index=False)
    non_matching_names_df2_html = non_matching_names_df2.to_html(index=False)
    
    matching_newcode_html = matching_newcode_df.to_html(index=False)
    non_matching_newcode_df1_html = non_matching_newcode_df1.to_html(index=False)
    non_matching_newcode_df2_html = non_matching_newcode_df2.to_html(index=False)
    
    matching_bankac_html = matching_bankac_df.to_html(index=False)
    non_matching_bankac_df1_html = non_matching_bankac_df1.to_html(index=False)
    non_matching_bankac_df2_html = non_matching_bankac_df2.to_html(index=False)

    summary = {
        "total_name_matches": len(matching_names_df),
        "total_name_non_matches_df1": len(non_matching_names_df1),
        "total_name_non_matches_df2": len(non_matching_names_df2),
        "total_newcode_matches": len(matching_newcode_df),
        "total_newcode_non_matches_df1": len(non_matching_newcode_df1),
        "total_newcode_non_matches_df2": len(non_matching_newcode_df2),
        "total_bankac_matches": len(matching_bankac_df),
        "total_bankac_non_matches_df1": len(non_matching_bankac_df1),
        "total_bankac_non_matches_df2": len(non_matching_bankac_df2)
    }

    return render_template('result.html', 
                           summary=summary,
                           matching_names_html=matching_names_html, 
                           non_matching_names_df1_html=non_matching_names_df1_html, 
                           non_matching_names_df2_html=non_matching_names_df2_html,
                           matching_newcode_html=matching_newcode_html, 
                           non_matching_newcode_df1_html=non_matching_newcode_df1_html, 
                           non_matching_newcode_df2_html=non_matching_newcode_df2_html,
                           matching_bankac_html=matching_bankac_html, 
                           non_matching_bankac_df1_html=non_matching_bankac_df1_html, 
                           non_matching_bankac_df2_html=non_matching_bankac_df2_html)

@app.route('/convert_excel', methods=['POST'])
def convert_excel():
    # Get the uploaded Excel file
    excel_file = request.files['excelFile']
    
    # Read the Excel file into a DataFrame
    df = pd.read_excel(excel_file)

    # Generate a CSV file name
    csv_filename = os.path.splitext(excel_file.filename)[0] + '.csv'
    
    # Convert the DataFrame to CSV
    df.to_csv(csv_filename, index=False)
    
    # Send the CSV file back to the user for download
    return send_file(csv_filename, as_attachment=True)

@app.route('/import_csv', methods=['POST'])
def import_csv():
    # Get the uploaded CSV file
    csv_file = request.files['csvFile']
    
    # Read the CSV file into a DataFrame
    df = pd.read_csv(csv_file)
    
    # Convert DataFrame to HTML for display
    table_html = df.to_html(index=False)
    
    # Render edit.html with the table
    return render_template('edit.html', table_html=table_html)

@app.route('/download/<filename>')
def download_file(filename):
    return send_file(filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
